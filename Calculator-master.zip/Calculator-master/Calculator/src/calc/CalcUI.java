package calc;
import java.io.IOException;
import java.util.Scanner;

import calc.Calculate; 

public class CalcUI extends Calculate {

	private static Scanner reader;

	CalcUI(int n1, int n2, char op) {
		super(n1, n2, op);
		// TODO Auto-generated constructor stub
	}
	
	void result(int n1,int n2,char op) throws IOException {
		super.result(n1, n2, op);
	}
	
	public static void main(String[] args) throws IOException {
        reader = new Scanner(System.in);
        System.out.print("Enter two numbers: ");
        int firstnumber = reader.nextInt();
        int secondnumber = reader.nextInt();
        System.out.print("Enter an operator (+, -, *, /): ");
        char operator = reader.next().charAt(0);
        CalcUI c = new CalcUI(firstnumber,secondnumber,operator);
        c.result(firstnumber,secondnumber,operator);
        
	}

}
