package calc;

import java.io.IOException;

import calc.Store;

class Calculate extends Store {
	char operation;
	int result;
	
	Calculate(int n1,int n2,char op)
	{
		super(n1,n2,op);
		operation = op;
	}
	
	void result(int n1, int n2,char op) throws IOException {
        int result;
        switch(c)
        {
            case '+':
                result = n1 + n2;
                break;
            case '-':
                result = n1 - n2;
                break;
            case '*':
                result = n1 * n2;
                break;
            case '/':
                result = n1 / n2;
                break;
            default:
                System.out.printf("Error! operator is not correct");
                return;
        }
        this.result = result;
        super.setResult(result);
        System.out.printf("%.1d %c %.1d = %.1d", n1, op, n2, result);
    }
		
}
	
	
	


